package com.cg.BookController.BookController.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.BookController.BookController.Beans.Book;

@Repository
public interface IBookDAO extends JpaRepository<Book, Integer> {

	/*
	 * @Query("from Book where id=:c") Optional<Book> findById(@Param("c") int id);
	 */

	@Query("from Book book where book.price between :price and :price1")
	List<Book> findByPri(@Param("price") int price, @Param("price1") int price1);

	@Query("from Book book where book.price > :price")
	List<Book> findBygreater(@Param("price") int price);

	@Query("from Book where name = :name")
	List<Book> getByName(@Param("name") String name);

	@Query("from Book where id = :id")
	Book getById(@Param("id") int id);
}
