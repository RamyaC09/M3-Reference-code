package com.cg.BookController.BookController.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BookController.BookController.Beans.Book;
import com.cg.BookController.BookController.Service.BookService;
import com.cg.BookController.BookController.Service.IBookService;
import com.cg.BookController.BookController.exception.BookException;

@RestController
public class BookController {
//	  @ResponseStatus(value=HttpStatus.NOT_FOUND,
//			  reason="product id is not found")
//	    @ExceptionHandler(Exception.class)
//    public void handleException() {
//	       
//	    }
	@Autowired
	IBookService bookService;

	@RequestMapping("/getAllBooks")
	public List<Book> getAllBooks() throws BookException {
		return bookService.getAllBooks();
	}

	@PostMapping("/addBook")
	public List<Book> addProduct(@Valid @RequestBody Book pro) throws BookException {

		return bookService.addBook(pro);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable int id) throws BookException {
		bookService.deleteBook(id);
		return new ResponseEntity<String>("Book with id " + id + " deleted", HttpStatus.OK);
	}

	@PutMapping("/update/{id}")
	public List<Book> updateBook(@PathVariable int id, @RequestBody Book pro) throws BookException {
		return bookService.updateBook(id, pro);
	}

	@RequestMapping("/getByprice/{price}/{price1}")
	List<Book> getByprice(@PathVariable int price, @PathVariable int price1) throws BookException {
		return bookService.findByPri(price, price1);
	}

	@RequestMapping("/greaterBy/{price}")
	List<Book> greaterBy(@PathVariable int price) throws BookException {
		return bookService.greaterBy(price);
	}

	@RequestMapping("/getByName/{name}")
	List<Book> getByName(@PathVariable String name) throws BookException {
		return bookService.getByName(name);
	}

	@RequestMapping("/getById")
	Book getById(@Valid @RequestParam int id) throws BookException {
		return bookService.getById(id);
	}

}
