package com.product.exception;

public class ProductException extends Exception {
	public ProductException()
	{
		super();
	}
	public ProductException(String msg)
	{
		super(msg);
	}
	

}
